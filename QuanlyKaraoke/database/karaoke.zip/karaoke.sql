-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.16-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for karaoke
CREATE DATABASE IF NOT EXISTS `karaoke` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `karaoke`;


-- Dumping structure for table karaoke.dichvu
CREATE TABLE IF NOT EXISTS `dichvu` (
  `madv` int(11) NOT NULL,
  `tendv` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_520_ci NOT NULL,
  `loaidichvu` varchar(20) NOT NULL,
  `soluong` int(11) NOT NULL,
  `dongia` char(10) NOT NULL,
  `dvt` varchar(20) NOT NULL,
  PRIMARY KEY (`madv`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table karaoke.dichvu: ~4 rows (approximately)
DELETE FROM `dichvu`;
/*!40000 ALTER TABLE `dichvu` DISABLE KEYS */;
INSERT INTO `dichvu` (`madv`, `tendv`, `loaidichvu`, `soluong`, `dongia`, `dvt`) VALUES
	(1, 'NUOC', '1', 50, '10000', ''),
	(2, 'BIMBIM', '2', 50, '5000', ''),
	(3, 'Thuốc lá', '1', 20, '20000', 'gói'),
	(4, 'Thuốc lắc', '', 20, '100000', 'viên');
/*!40000 ALTER TABLE `dichvu` ENABLE KEYS */;


-- Dumping structure for table karaoke.hoadon
CREATE TABLE IF NOT EXISTS `hoadon` (
  `sohd` int(11) NOT NULL AUTO_INCREMENT,
  `maphong` int(11) NOT NULL,
  `khachhang` varchar(50) DEFAULT NULL,
  `diachi` varchar(50) DEFAULT NULL,
  `giovao` datetime NOT NULL,
  `giora` datetime DEFAULT NULL,
  `trangthai` int(11) NOT NULL,
  PRIMARY KEY (`sohd`),
  KEY `FK_hoadon_phong` (`maphong`),
  CONSTRAINT `FK_hoadon_phong` FOREIGN KEY (`maphong`) REFERENCES `phong` (`maphong`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table karaoke.hoadon: ~7 rows (approximately)
DELETE FROM `hoadon`;
/*!40000 ALTER TABLE `hoadon` DISABLE KEYS */;
INSERT INTO `hoadon` (`sohd`, `maphong`, `khachhang`, `diachi`, `giovao`, `giora`, `trangthai`) VALUES
	(1, 1, NULL, NULL, '2016-09-26 08:36:59', NULL, 0),
	(2, 2, NULL, NULL, '2016-09-26 08:37:17', NULL, 0),
	(3, 2, NULL, NULL, '2016-09-29 16:50:29', NULL, 0),
	(4, 2, NULL, NULL, '2016-09-29 16:51:28', NULL, 0),
	(5, 1, NULL, NULL, '2016-11-13 09:52:54', NULL, 1),
	(6, 3, NULL, NULL, '2016-11-13 10:56:14', NULL, 0),
	(7, 1, NULL, NULL, '2016-11-13 11:00:25', NULL, 0),
	(8, 1, NULL, NULL, '2016-11-13 15:30:17', NULL, 0);
/*!40000 ALTER TABLE `hoadon` ENABLE KEYS */;


-- Dumping structure for table karaoke.hoadon_dichvu
CREATE TABLE IF NOT EXISTS `hoadon_dichvu` (
  `sohd` int(11) NOT NULL,
  `madv` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  PRIMARY KEY (`sohd`,`madv`),
  KEY `FK_hoadon_dichvu_dichvu` (`madv`),
  CONSTRAINT `FK_hoadon_dichvu_dichvu` FOREIGN KEY (`madv`) REFERENCES `dichvu` (`madv`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_hoadon_dichvu_hoadon` FOREIGN KEY (`sohd`) REFERENCES `hoadon` (`sohd`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table karaoke.hoadon_dichvu: ~14 rows (approximately)
DELETE FROM `hoadon_dichvu`;
/*!40000 ALTER TABLE `hoadon_dichvu` DISABLE KEYS */;
INSERT INTO `hoadon_dichvu` (`sohd`, `madv`, `soluong`) VALUES
	(1, 1, 1),
	(1, 2, 8),
	(2, 1, 3),
	(2, 2, 0),
	(3, 1, 2),
	(3, 2, 1),
	(4, 1, 1),
	(4, 2, 6),
	(6, 1, 0),
	(6, 2, 1),
	(7, 1, 3),
	(7, 2, 1),
	(8, 1, 3),
	(8, 2, 4);
/*!40000 ALTER TABLE `hoadon_dichvu` ENABLE KEYS */;


-- Dumping structure for table karaoke.phieudatphong
CREATE TABLE IF NOT EXISTS `phieudatphong` (
  `sophieu` int(11) NOT NULL,
  `tenkh` varchar(50) DEFAULT NULL,
  `loaiphong` char(10) DEFAULT NULL,
  `tiendatcoc` char(10) NOT NULL,
  `giovao` datetime NOT NULL,
  `ghichu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`sophieu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table karaoke.phieudatphong: ~0 rows (approximately)
DELETE FROM `phieudatphong`;
/*!40000 ALTER TABLE `phieudatphong` DISABLE KEYS */;
/*!40000 ALTER TABLE `phieudatphong` ENABLE KEYS */;


-- Dumping structure for table karaoke.phong
CREATE TABLE IF NOT EXISTS `phong` (
  `maphong` int(11) NOT NULL,
  `tenphong` varchar(50) NOT NULL,
  `giaphong` char(10) NOT NULL,
  `trangthai` int(2) NOT NULL,
  `mota` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`maphong`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table karaoke.phong: ~3 rows (approximately)
DELETE FROM `phong`;
/*!40000 ALTER TABLE `phong` DISABLE KEYS */;
INSERT INTO `phong` (`maphong`, `tenphong`, `giaphong`, `trangthai`, `mota`) VALUES
	(0, 'PHONG 4', '50000', 0, NULL),
	(1, 'PHONG 1', '50000', 1, NULL),
	(2, 'PHONG 2', '100000', 1, NULL),
	(3, 'PHONG 3', '50000', 1, NULL);
/*!40000 ALTER TABLE `phong` ENABLE KEYS */;


-- Dumping structure for table karaoke.taikhoan
CREATE TABLE IF NOT EXISTS `taikhoan` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` char(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table karaoke.taikhoan: ~0 rows (approximately)
DELETE FROM `taikhoan`;
/*!40000 ALTER TABLE `taikhoan` DISABLE KEYS */;
INSERT INTO `taikhoan` (`id`, `username`, `password`) VALUES
	(1, 'bac', '1234'),
	(2, 'duc', '12345');
/*!40000 ALTER TABLE `taikhoan` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
